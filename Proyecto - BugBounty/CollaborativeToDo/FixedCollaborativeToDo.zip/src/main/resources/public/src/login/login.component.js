"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var users_service_1 = require("../users/users.service");
var LoginComponent = (function () {
    function LoginComponent(router, userService) {
        var _this = this;
        this.router = router;
        this.userService = userService;
        userService.getCurrentUser().then(function (user) {
            _this.checkUser(user);
        });
    }
    LoginComponent.prototype.checkUser = function (user) {
        this.user = user;
        if (this.user.id) {
            this.router.navigate(["/todos"]);
        }
    };
    LoginComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.nombreUsuario).then(function (user) { return _this.checkUser(user); });
    };
    LoginComponent.prototype.ngAfterViewInit = function () {
        this._inputElement.nativeElement.focus();
    };
    return LoginComponent;
}());
__decorate([
    core_1.ViewChild("loginInput"),
    __metadata("design:type", core_1.ElementRef)
], LoginComponent.prototype, "_inputElement", void 0);
LoginComponent = __decorate([
    core_1.Component({
        selector: 'app',
        template: "<div style=\"min-height: 100%;min-height: 100vh;display: flex;align-items: center;justify-content: center;\">\n                <div class=\"login\" style=\"max-width:300px;\">\n                    <div class=\"panel panel-success\">\n                      <div class=\"panel-heading\">\n                        <h3 class=\"panel-title\">Ingrese un nombre de usuario</h3>\n                      </div>\n                      <div class=\"panel-body\">\n                        <form #loginForm=\"ngForm\" (ngSubmit)=\"login()\">\n                          <div class=\"input-group\">\n                              <input #loginInput class=\"form-control\" [(ngModel)]=\"nombreUsuario\" placeholder=\"Nombre de usuario\" ng-model=\"password\" name=\"username\" id=\"username\" required>\n                              <span class=\"input-group-btn\">\n                                <button class=\"btn btn-primary\" type=\"submit\">\n                                  <span class=\"glyphicon glyphicon-ok\" aria-hidden=\"true\"></span>\n                                </button>\n                              </span>\n                          </div>\n                        </form>\n                      </div>\n                    </div>\n                </div>\n              </div>",
        providers: [users_service_1.UserService]
    }),
    __metadata("design:paramtypes", [router_1.Router,
        users_service_1.UserService])
], LoginComponent);
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map