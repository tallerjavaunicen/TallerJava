"use strict";
var Todo = (function () {
    function Todo() {
    }
    return Todo;
}());
exports.Todo = Todo;
//# sourceMappingURL=todo.js.map