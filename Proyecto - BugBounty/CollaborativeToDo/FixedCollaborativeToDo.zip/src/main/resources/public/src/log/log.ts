import { User } from '../users/user';

export class Log {
  id: String;
  action: String;
  user: User;
}
