"use strict";
var Log = (function () {
    function Log() {
    }
    return Log;
}());
exports.Log = Log;
//# sourceMappingURL=log.js.map