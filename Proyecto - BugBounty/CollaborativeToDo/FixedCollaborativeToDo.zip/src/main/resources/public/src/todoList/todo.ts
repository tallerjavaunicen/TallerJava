import { User } from '../users/user';

export class Todo {
  id: String;
  user: User;
  content: String;
}
