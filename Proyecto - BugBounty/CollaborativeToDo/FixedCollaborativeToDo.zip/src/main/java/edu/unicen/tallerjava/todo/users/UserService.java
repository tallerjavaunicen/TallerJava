package edu.unicen.tallerjava.todo.users;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.unicen.tallerjava.todo.log.LogService;

@Service
public class UserService {
	@Autowired
	LogService logSvc;

	public static final User DEFAULT_USER = new User("Admin", UUID.randomUUID());
	TreeSet<User> users = new TreeSet<>((User u, User u2) -> u.getId().compareTo(u2.getId()));

	public List<User> getUsers() {
		ArrayList<User> arrayList = new ArrayList<>(this.users);
		Collections.sort(arrayList, (User u, User u2) -> u.getName().compareTo(u2.getName()));
		return arrayList;
	}

	public void addUser(User user) {
		logSvc.addLog("Se agreg� el usuario " + user.getName(), user);
		this.users.add(user);
	}

	public void clearUsers() {
		users.clear();
		logSvc.clear();
	}

	public void setLogSvc(LogService logSvc) {
		this.logSvc = logSvc;
	}

}
